package com.example.kimziapplication.di


import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object MainModule {
    @Provides
    @Singleton
    fun ProvidesUserName()="Kimiya BazgirFard"
    //یه شکل دیگه تابع بالا میشه اینجوری
    /*fun ProvidesUserName():String{
        return "Kimiya BazgirFard"
    }*/

}